<!-- toast.php -->
<div class="toast" id="globalToast">
    <p id="globalToastMessage"></p>
</div>
